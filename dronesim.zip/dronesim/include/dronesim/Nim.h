#ifndef NIM_H
#define NIM_H

#include <vector>

const float h = 0.01f; //time step

class Nim {
public:
	// Constructor base class NIM
	Nim() {

	}
	~Nim() = default;

	// function to calculate the x+1 from forward_euler method
	std::vector<float> forward_euler(const std::vector<float> &fxu, const std::vector<float> &states);
	// calculate using runge_kutta method
	std::vector<float> runge_kutta(const std::vector<float>& fxu, const std::vector<float>& states, const std::vector<float> &k);

private:
	std::vector<float> next_itr;
};

#endif //NIM_H