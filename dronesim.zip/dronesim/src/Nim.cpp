#include "../include/dronesim/Nim.h"

std::vector<float> Nim::forward_euler(const std::vector<float> &fxu, const std::vector<float> &states )
{
	next_itr.resize(fxu.size());
	for (int i = 0; i < fxu.size(); i++)
	{
		next_itr[i] = states[i] + h * fxu[i];
	}
	return next_itr;
}

std::vector <float> Nim::runge_kutta(const std::vector<float>& fxu, const std::vector<float>& states, const std::vector<float> &k) 
{
	
	next_itr.resize(fxu.size());
	for (int i = 0; i < fxu.size(); i++)
	{
		next_itr[i] = states[i] + (1 / 6) * h * (k[0] + 2 * k[1] + 2 * k[2] + k[3]);
	}
	return next_itr;
}
