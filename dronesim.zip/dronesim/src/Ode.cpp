#include "../include/dronesim/Ode.h"

#include <cmath>

std::vector<float> Ode::changefxu() {
	m_fxu[0] = m_states[3];
	m_fxu[1] = m_states[4];
	m_fxu[2] = m_inputs[1];
	m_fxu[3] = -(1/drone_mass)*(m_inputs[0]*sin(m_states[2]) + C_drag*sqrt(m_states[3]*m_states[3] + m_states[4] * m_states[4])*m_states[3]);
	m_fxu[4] = (1 / drone_mass) * (m_inputs[0] * sin(m_states[2]) - C_drag * sqrt(m_states[3] * m_states[3] + m_states[4] * m_states[4]) * m_states[3]) - g;
	return m_fxu;
}

std::vector<float> Ode::getStates() {
	return m_states;
}

std::vector<float> Ode::getInputs() {
	return m_inputs;
}

void Ode::updateStates(const std::vector<float>& STATES) {
	m_states = STATES;
}

void Ode::updateInput(const std::vector<float>& INPUTS) {
	m_inputs = INPUTS;
}
