#include <chrono>
#include <memory>
#include <iostream>

#include "../include/dronesim/Nim.h"
#include "../include/dronesim/Ode.h"
#include "std_msgs/msg/float32.hpp"

#include "rclcpp/rclcpp.hpp"
//#include "dronesim_interfaces/msg/num.hpp"

using namespace std::chrono_literals;

const std::vector<float> initInput = {2, 2};
const std::vector<float> initState = {10, 10, 10, 10, 10};

class Dynamics : public rclcpp::Node {
public:
  Dynamics()
  : Node("Dynamics"), count_(0)
  {
    std::cout << "init...\n"; 
    this->init();
    publisher_ = this->create_publisher<std_msgs::msg::Float32>("topic", 10);    // CHANGE
    timer_ = this->create_wall_timer(
      500ms, std::bind(&Dynamics::timer_callback, this));
  }

private:
  std::vector<float> nextStates(const std::vector<float>& resultOfNim) {
	nextState = resultOfNim;
	return nextState;
  }


  void init() {
    // Init inputs/states & Allocate space
    this->Inputs = { initInput[0], initInput[1] };
    this->States = { initState[0], initState[1], initState[2], initState[3], initState[4] };
	this->fxu.resize(States.size());
	this->nextItr.resize(fxu.size());
    ode_withoutCargo.updateInput(this->Inputs);
	ode_withoutCargo.updateStates(this->States);
	this->States = ode_withoutCargo.getStates();
  }


  void timer_callback() {
    // NIM step

    std::vector<float> temp = ode_withoutCargo.getStates();
    temp = ode_withoutCargo.getInputs();
    this->fxu = ode_withoutCargo.changefxu();
	this->nextItr = nextStates(nim_method.forward_euler(fxu, States));
	ode_withoutCargo.updateStates(nextItr);
    this->States = ode_withoutCargo.getStates();
    

    // Prep message 
    auto message = std_msgs::msg::Float32();   
    for (int i = 0; i < (int)States.size(); i++) {
        message.data = States[i]; 
        std::cout << i << ": "<< message.data << "\n";
        RCLCPP_INFO(this->get_logger(), "Publishing: '%f'", message.data);
        publisher_->publish(message);
    } 
  }
  // ODE & NIM
  std::vector<float> Inputs;
  std::vector<float> States;
  std::vector<float> fxu;
  std::vector<float> nextItr;
  std::vector<float> nextState;

  Ode ode_withoutCargo;
  Nim nim_method;

  // Publisher
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr publisher_;         // CHANGE
  size_t count_;
};

int main(int argc, char * argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Dynamics>());
  rclcpp::shutdown();
  return 0;
}
